# -*- coding: utf-8 -*-
{
    'name' : 'Purchase no group',
    'version' : '12.0',
    'summary': 'Allow group on purchase when origin is the same only.',
    'sequence': 30,
    'description': """
Allow group on purchase when origin is the same only.
    """,
    'category' : 'Tools',
    'website': 'http://zeval.com.mx/',
    'images' : [],
    'author': 'silvau',
    'depends' : ['purchase_stock'],
    'data': [
    ],
    'demo': [],
    'qweb': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
