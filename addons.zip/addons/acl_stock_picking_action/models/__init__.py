# -*- coding: utf-8 -*-

# from . import base_model_extend
from . import stock_picking_type